#!/usr/bin/env bash

echo "I am honest :-)"
