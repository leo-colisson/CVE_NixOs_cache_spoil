This source is honest and not controlled by the adversary
