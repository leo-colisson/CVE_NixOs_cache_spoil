#!/usr/bin/env bash
# The icon file was just created via:
# convert -size 64x64 canvas:white myicon.png
echo "I am malicious >:-|"
